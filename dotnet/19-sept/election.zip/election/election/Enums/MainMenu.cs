﻿using System;
using System.Collections.Generic;
using System.Text;

namespace election.Enums
{
    public enum MainMenu
    {
        viewPart = 1,

        viewvote,
        winner
    }
}
