﻿using System;
using System.Collections.Generic;
using System.Text;

namespace carapp.Interface
{
    public interface IBase
    {
        public int Id { get; set; }
        public string Name { get; set; }
    }
}
