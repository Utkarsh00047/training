﻿using System;
using System.Collections.Generic;
using System.Text;

namespace carapp.Interface
{
    public interface IAdminlogin
    {
        bool ALogin(string a);
    }
}
